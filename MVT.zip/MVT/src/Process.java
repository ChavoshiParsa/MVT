public record Process(int id, int size) {
}
